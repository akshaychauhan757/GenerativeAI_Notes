import pandas as pd
from ctgan import CTGAN

class SynthLogic:
    @staticmethod
    def process_data(file):
        """Reads the CSV and maps the data architecture."""
        df = pd.read_csv(file)
        # Automatically detects categories (discrete) vs continuous numbers
        discrete_cols = [col for col in df.columns if df[col].dtype == 'object' or df[col].nunique() < 10]
        return df, discrete_cols

    @staticmethod
    def synthesize(df, discrete_cols, epochs=50, n_rows=500):
        """Trains the AI model and generates new data."""
        # The CTGAN model acts as the "Architect"
        model = CTGAN(epochs=epochs)
        model.fit(df, discrete_cols)
        return model.sample(n_rows)