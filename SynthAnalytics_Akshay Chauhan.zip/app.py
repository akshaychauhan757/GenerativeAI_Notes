import streamlit as st
import pandas as pd
import time
from src.engine import SynthLogic

st.set_page_config(page_title="SynthAnalytics | Enterprise", layout="wide")

# Elite UI CSS
st.markdown("""
<style>
    .stApp { background-color: #0A0E17; color: #FFFFFF; }
    .main-title { 
        background: linear-gradient(90deg, #00F2FE, #4FACFE);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 3rem; font-weight: 800; text-align: center;
    }
    .stButton>button {
        background: linear-gradient(135deg, #4FACFE 0%, #00F2FE 100%);
        color: white; border-radius: 10px; border: none; font-weight: bold; height: 3em;
    }
</style>
""", unsafe_allow_html=True)

st.markdown('<h1 class="main-title">SynthAnalytics</h1>', unsafe_allow_html=True)

with st.sidebar:
    st.header("Control Panel")
    uploaded_file = st.file_uploader("Ingest CSV", type="csv")
    gen_count = st.slider("Target Records", 100, 5000, 1000)

if uploaded_file:
    df, discrete_cols = SynthLogic.process_data(uploaded_file)
    st.write("### Input Data Preview")
    st.dataframe(df.head(10), use_container_width=True)

    if st.button("EXECUTE GENERATIVE PROTOCOL"):
        with st.status("Training Neural Engine...", expanded=True) as status:
            synth_df = SynthLogic.synthesize(df, discrete_cols, epochs=50, n_rows=gen_count)
            status.update(label="Synthesis Complete!", state="complete")
        
        st.success(f"Generated {gen_count} new records.")
        st.dataframe(synth_df.head(10), use_container_width=True)
        
        csv = synth_df.to_csv(index=False).encode('utf-8')
        st.download_button("⬇️ Export Dataset", data=csv, file_name='synthetic_data.csv', mime='text/csv')
else:
    st.info("System Standby: Awaiting Data Ingestion...")